<?php
session_start();

 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#3FBFA5">

    <meta charset="utf-8">
    <link rel="stylesheet" href="css/master.css">
    <link rel="stylesheet" href="css/cpwd.css">
    <!-- <script src="scripts/main.js" charset="utf-8"></script> -->
    <title>MAN -- HOME</title>
  </head>
  <body>
    <header>

        <h2 class="header-title">MAN</h2>

    </header>
    <main>

<section class="login-section">
  <div class="loginbox">
    <div class="h3">CHANGE PASSWORD<span class="h6"><?php echo $_SESSION['Admin'];?></span> </div>

    <form class="" action="incs/cpwd.inc.php" method="post">
        <label for="Cpwd">Current PASSWORD</label> 
        <input type="password" name="cpwd" id="cpwd" placeholder="Name"> <br>
        <label for="nPwd"> New Password</label> 
        <input type="password" name="npwd" id="nPwd" placeholder="password"> <br>

        <label for="rPwd"> Repeat Password</label> 
        <input type="password" name="rpwd" id="rPwd" placeholder="password"> <br>

        <button type="submit" name="changepwd">Change</button>

    </form>

  </div>
</section>

    </main>

  </body>

</html>

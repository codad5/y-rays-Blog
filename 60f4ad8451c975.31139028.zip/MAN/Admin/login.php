<?php
session_start();
if (isset($_SESSION['Admin'])) {
  header("location:index.php");
}
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#3FBFA5">

    <meta charset="utf-8">
    <link rel="stylesheet" href="css/master.css">
    <link rel="stylesheet" href="css/login.css">
    <!-- <script src="scripts/main.js" charset="utf-8"></script> -->
    <title>MAN -- HOME</title>
  </head>
  <body>
    <header>

        <h2 class="header-title">MAN</h2>

    </header>
    <main>

<section class="login-section">
  <div class="loginbox">
    <div class="h3">LOGIN AS ADMIN @MAN. <span class="h6">WORLD.ADMIN</span> </div>

    <form class="" action="incs/login.inc.php" method="post">
        <label for="Name">NAME</label> <br>
        <input type="text" name="Name" id="Name" placeholder="Name"> <br>
        <label for="Pwd">Password</label> <br>
        <input type="password" name="Pwd" id="Pwd" placeholder="password"> <br>
        <button type="submit" name="login">LOGIN</button>

    </form>

  </div>
</section>

    </main>

  </body>

</html>

<?php
session_start();
require_once 'incs/functions.inc.php';
require_once 'incs/dbh.inc.php';
if (!isset($_SESSION['Admin'])) {
  header("location:login.php");
}
else {
  $cuser = $_SESSION['Admin'];
  $uidExists = UidExist($conn, $cuser);

  if ($uidExists['firstLogin'] <= 0) {
    header("location:cpwd.php?error=firstLogin");
  }

  $sql = "SELECT * FROM message ORDER BY msgId;";
  $resultmsg = mysqli_query($conn, $sql);
  $resultcheck = mysqli_num_rows($resultmsg);

}
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#3FBFA5">

    <meta charset="utf-8">
    <link rel="stylesheet" href="css/master.css">
    <link rel="stylesheet" href="css/index.css">
    <!-- <script src="scripts/main.js" charset="utf-8"></script> -->
    <title>MAN -- HOME <?php echo $_SESSION['Admin']; ?></title>
  </head>
  <body onload="moveToButtom()">
    <header>

        <h2 class="header-title">MAN  </h2> 
        <div class="menuIcon">
          <svg width="80%" height="80%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 18H3V16H12V18ZM21 13H3V11H21V13ZM21 8H12V6H21V8Z" fill="black"/>
          </svg>

        </div>



    </header>
    <div class="menu">
      <ul class="menul">
        <li onclick="openmodal('uploadModal')">UPLOAD A PROJECT </li>
        <li onclick="href('cpwd.php')">CHANGE PASSWORD</li>
        <li onclick="openmodal('changeColorModal')">CHANGE COLOR </li>
        <li onclick="logout()">LOGOUT</li>
      </ul>

    </div>

    <div class="modal">
      <div class="modalCloseBtn"><svg width="54" height="54" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M19.97 21.385L16.614 18.029C15.1661 18.6882 13.5908 19.0204 12 19.002C10.3599 19.0224 8.73671 18.6684 7.254 17.967C6.10468 17.4063 5.07264 16.6318 4.213 15.685C3.30049 14.7069 2.5833 13.5634 2.1 12.316L2 12.002L2.105 11.686C2.82781 9.84231 4.04426 8.23318 5.621 7.03501L3 4.41401L4.413 3.00201L21.382 19.971L19.972 21.385H19.97ZM7.036 8.45101C5.75792 9.34693 4.74865 10.5747 4.117 12.002C5.47142 15.1269 8.59587 17.1087 12 17.002C13.0498 17.0106 14.0936 16.8416 15.087 16.502L13.287 14.702C12.8863 14.8984 12.4462 15.001 12 15.002C10.3475 14.9916 9.01037 13.6546 9 12.002C9.00048 11.5548 9.10309 11.1136 9.3 10.712L7.036 8.45101ZM19.852 15.612L18.46 14.221C19.0456 13.5589 19.5256 12.8105 19.883 12.002C18.5304 8.87559 15.4047 6.89309 12 7.00201C11.753 7.00201 11.505 7.01101 11.265 7.02801L9.5 5.26101C10.3216 5.08525 11.1598 4.99841 12 5.00201C13.6401 4.98166 15.2633 5.33564 16.746 6.03701C17.8953 6.59775 18.9274 7.37221 19.787 8.31901C20.6991 9.29598 21.4163 10.4381 21.9 11.684L22 12.002L21.895 12.318C21.4268 13.5361 20.7342 14.6555 19.853 15.618L19.852 15.612Z" fill="black"/>
</svg>
</div>
      <div class="changeColorModal modalBox">
        <div class="modalContainer">
        <input type="color" name="" value="#3FBFA5" id="colorChanger">
        <input type="button" name="" value="MAKE CHANGE" onclick="changeColor()">
      </div>
      </div>
      <div class="uploadModal modalBox">
        <div class="modalContainer">

        <a href="uploads.php" class="modalLink">View all upload</a>
          <form action="incs/upload.inc.php"method="post" enctype="multipart/form-data">
          <label for="Filedsp">Write abt the File</label>
          <input type="text" name="Filedsp" id="Filedsp">
            <input type="file" name="upload" value="" id="FileSelector"><br>
              <button type="submit" name="uploadFile" value="<?php echo $_SESSION['Admin']; ?>">Submit</button>
          </form>
        

      </div>
      </div>

    </div>
    <main class="mainBody">


      <div class="message">
        <div class="sender" style="color:red;background:gold;">
          This Group Started
        </div>
      </div>

      <!-- <div class="message">
        <div class="receiver">

        </div>
      </div> -->


            <?php

            if ($resultcheck > 0) {
	while ($row = mysqli_fetch_assoc($resultmsg)) {

    if ($row['sender'] === $cuser) {
      $style = "sender";
    }

    else {
      if ($row['sender'] === "CHUKS")  {
        $style = "receiver chuks";
      }
      elseif ($row['sender'] === "NAP") {
        $style = "receiver nap";
      }
      elseif ($row['sender'] === "BAT") {
        $style = "receiver bat";
      }
      elseif ($row['sender'] === "CHIBUEZE") {
        $style = "receiver chib";
      }
      else {
        $style = "receiver";
      }
    }

    if ($row['msgType'] === 'file') {
      $style = $style." file";
      $row['msg'] = "<a href='upload/".$row['FileNam']."'>".$row['msg']."</a>";
    }



    echo " <div class='message'>
        <div class='".$style."'>
        ".$row['msg']."
        <code>".$row['sndDate']."</code>
        </div>
      </div>";


  }
}
else {
  echo " <div class='message'>
      <div class='sender'>
      It seems there is no message!!
      </div>
    </div>";
}


             ?>
             <div class="message" id="lastbox">

              </div>



    </main>
    <footer>

      <form class="messageForm" action="incs/sendmsg.inc.php" method="post">
        <div class="msgInputBox">
          <textarea class="textbox" name="message" rows="3" cols="80" wrap="soft" maxlength="754" placeholder="Type Your Message Here"></textarea>
        </div>
        <div class="sendBtn">
          <button type="button" class="sendButn" name="sendmsg" value="<?php echo $_SESSION['Admin']; ?>"><svg xmlns="http://www.w3.org/2000/svg" width="53.155" height="50" viewBox="0 0 53.155 50">
  <g id="Path_1" data-name="Path 1" transform="translate(29.155 0) rotate(90)" fill="#1d201e" class="sendIcon">
    <path d="M 48.95612716674805 28.12909698486328 L 26.5524845123291 17.90042114257813 L 25.12680053710938 -0.2527408599853516 L 24.14311027526855 -0.3342608511447906 L 19.60851669311523 17.89912414550781 L 1.09018611907959 27.99174690246582 L 24.63505935668945 -22.82516670227051 L 48.95612716674805 28.12909698486328 Z" stroke="none"/>
    <path d="M 24.64178276062012 -21.65032196044922 L 2.180374145507813 26.82814598083496 L 19.17632102966309 17.56523513793945 L 23.65789031982422 -0.4549407958984375 L 25.62525939941406 -0.2918906211853027 L 27.02789878845215 17.56783676147461 L 47.91225051879883 27.10285949707031 L 24.64178276062012 -21.65032196044922 M 24.62833023071289 -24 L 50 29.15533828735352 L 26.07706069946289 18.23300933837891 L 24.62833023071289 -0.2135906219482422 L 20.04071044921875 18.23300933837891 L 0 29.15533828735352 L 24.62833023071289 -24 Z" stroke="none" fill="#707070"/>
  </g>
</svg>
</button>
        </div>
      </form>


    </footer>

  </body>
  <script type="text/javascript">
  var textBox = document.querySelector('.textbox');

  textBox.addEventListener("input", function(){
    let x = textBox.value;

    if (x.length <= 0) {
      document.querySelector(".sendButn").type = "";

    }
    else {
      document.querySelector(".sendButn").type = "submit";
    }

  });

function moveToButtom(){
  console.log(window.location.href);
  let location = window.location.href;

  let lastBox = location.substr(-7, 7);





  if (lastBox !== "lastbox") {
    window.location.assign(location+"#lastbox");
  }

};

var menuIcon = document.querySelector(".menuIcon");

var menu = document.querySelector(".menu");
menuIcon.addEventListener("click", function(){
  drmenu("200px");
});
menuIcon.addEventListener("mouseover", function(){
  drmenu("200px");
});
menu.addEventListener("click", function(){

  drmenu("200px");
});
document.querySelector(".mainBody").addEventListener("click", function(){
  drmenu("0px");


});

document.querySelector(".mainBody").addEventListener("mouseover", function(){
  drmenu("0px");


});
// modalCloseBtn
document.querySelector(".modalCloseBtn").addEventListener("click", function(){
  document.querySelector(".modal").style.display="none";
  document.querySelector(".modalBox").style.display="none";

});

function drmenu(value){
  menu.style.height = value;

};

function openmodal(value){
    let omr = document.querySelector("."+value);
    let modal = document.querySelector(".modal");

    modal.style.display="inline-flex";
    omr.style.display="inline-flex";
    
    if (value === "changeColorModal") {
      drmenu("0px");
      document.querySelector(".uploadModal").style.display="none";
    }
    else{
      // changeColorModal
      drmenu("0px");
      document.querySelector(".changeColorModal").style.display="none";
    }
    
};

function logout(){
  window.location.assign("incs/logout.inc.php");
}
function href(value){
  window.location.assign(value);
}

// document.querySelector(":root").style="--theme-color:blue";

function changeColor(){
  let color = document.querySelector("#colorChanger").value;
  let colorChanege = "--theme-color:"+color+";";
  console.log(colorChanege);
  document.querySelector(":root").style= colorChanege;

}



  </script>

</html>

<?php

session_start();

if (!isset($_SESSION['Admin'])) {
    header("location:../");

}

if (!isset($_POST['changepwd'])) {
    header("location:../");
}

echo $_SESSION['Admin'];

require_once "functions.inc.php";
require_once "dbh.inc.php";
    $name = $_SESSION['Admin'];

  $cpwd = $_POST['cpwd'];
  $cpwd  = filter_var($cpwd, FILTER_SANITIZE_STRING);
  $npwd = $_POST['npwd'];
  $npwd = filter_var($npwd, FILTER_SANITIZE_STRING);
  $rpwd = $_POST['rpwd'];
  $rpwd = filter_var($rpwd, FILTER_SANITIZE_STRING);

  

  if (emptyinput($cpwd, $npwd) !== false) {
    header("location:../cpwd.php?emptyinput");
  }
   if (emptyinput($cpwd, $rpwd) !== false) {
    header("location:../cpwd.php?emptyinput");
  }

  if ($npwd !== $rpwd) {
      header("location:../cpwd.php?pwdNotSameinput");
  }

    if (UidExist($conn, $name) === false) {
        header("location:../cpwd.php?pwdNotSameinput");
    }

       if (cpwd($conn, $name, $cpwd, $npwd) !== false) {
           header("location:../index.php");
       }
       else {
           header("location:../cpwd.php");
       }
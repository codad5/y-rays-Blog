<?php

function emptyinput($name, $pwd){
  $result;
  if (empty($name) || empty($pwd)) {
    $result = true;

  }

  else {
    $result = false;

  }
  return $result;


}


function UidExist($conn, $name){
  $sql ="SELECT * FROM admin WHERE AdminName = ?;";
  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt, $sql)) {
    header("location:../admin/login.php?error=stmtfailed#formbox");
    exit();
  }

  mysqli_stmt_bind_param($stmt, "s", $name);
  mysqli_stmt_execute($stmt);

  $resultData = mysqli_stmt_get_result($stmt);

  if ($row = mysqli_fetch_assoc($resultData)) {
    return $row;
  }

  else {
    $result = false;
    return $result;
  }

  mysqli_stmt_close($stmt);

}






function loginUser($conn, $name, $pwd){
  $uidExists = UidExist($conn, $name);

  if (UidExist($conn, $name) !== false) {
    // code...
    $pwdHashed = $uidExists['AdminPwd'];
  $checkPwd = password_verify($pwd, $pwdHashed);

  if ($checkPwd === false) {
    header("location:../login.php?error=wrongpassword#lastbox");
    exit();
  }

  else if ($checkPwd === true) {
    session_start();
    $_SESSION['Adminid'] = $uidExists['AdminId'];
    $_SESSION['Admin'] = $uidExists['AdminName'];
    header("location:../index.php");
    exit();

  }




  }
  else {
    header("location:../login.php");
  }


}


function sendmsg($conn, $msg, $sender, $msgType, $filename){

  $sql ="INSERT INTO message (msg, sender, msgType, FileNam) VALUES (?,?,?,?);";

  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt, $sql)) {
    header("location:../index.php?error=stmtfailed");
    exit();
  }





  mysqli_stmt_bind_param($stmt, "ssss", $msg, $sender, $msgType, $filename);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_close($stmt);

  header("location:../index.php?cng=sucess#lastbox");
  exit();

}

function   cpwd($conn, $name, $cpwd, $npwd){
  $uidExists = UidExist($conn, $name);

  if ($uidExists === false) {
    header("location:../index.php?error=wronglogin#formbox");
    exit();
  }


  $pwdHashed = $uidExists['AdminPwd'];
  $checkPwd = password_verify($cpwd, $pwdHashed);

  if ($checkPwd === false) {
    header("location:../cpwd.php?error=wrongpassword");
    exit();
  }

  else if ($checkPwd === true) {
    $hashedPwd = password_hash($npwd, PASSWORD_DEFAULT);
    $sql ="UPDATE admin set AdminPwd='".$hashedPwd."' WHERE AdminName='".$name."';";
    $resultfinal = mysqli_query($conn, $sql);
    $sql ="UPDATE admin set firstLogin='2' WHERE AdminName='".$name."';";
    $resultfinal = mysqli_query($conn, $sql);
    return   $resultfinal;
    









  }


}


function uploadFile($conn, $sender, $filedsp, $file, $fileNameNew, $fileName, $fileTmpName, $fileSize, $fileError, $fileType, $fileExt, $fileActualExt, $allowed){
  
  if (in_array($fileActualExt, $allowed)) {
    if ($fileError === 0) {
        if ($fileSize < 100000000000) {
          $fileNameNew = uniqid('', true).".".$fileActualExt;
          $fileDestination = "../upload/".$fileNameNew;
          move_uploaded_file($fileTmpName, $fileDestination);
          sendmsg($conn, $filedsp, $sender, "file", $fileNameNew);
          header('Location:../?error=fileuploadsucess');
         

        }
        else {
          header("location:../admin/?filetobig");
        }
    }

    else {
      header("location:../admin/?fileerror");
    }
  }
  else {
    header("location:../admin/?fileerror=wrongfiletype");
  }
}
<?php
    session_start();
    require_once 'functions.inc.php';
    require_once 'dbh.inc.php';
    if (!isset($_POST['uploadFile'])) {
        # code...
        header('Location:../');
    }

    if (!isset($_FILES['upload'])) {
        header('Location:../');
    }

    if ($_POST['uploadFile'] !== $_SESSION['Admin']) {
        header('Location:../');
    }

    $sender = $_SESSION['Admin'];
    $filedsp = $_POST['Filedsp'];
    $file = $_FILES["upload"];
    $fileName =  $_FILES['upload']['name'];
   $fileTmpName =  $_FILES['upload']['tmp_name'];
   $fileSize =  $_FILES['upload']['size'];
   $fileError =  $_FILES['upload']['error'];
   $fileType =  $_FILES['upload']['type'];

   $fileExt = explode('.', $fileName);
   $fileActualExt = strtolower(end($fileExt));

   $allowed = array('jpg', 'jpeg', 'png', 'gif', 'blend', 'pdf', 'mp3', 'mp4', 'html', 'php', 'zip');
   $fileNameNew = "";

    if (UidExist($conn, $sender) !== true) {
        // header("location:../");
    }
      uploadFile($conn, $sender, $filedsp, $file, $fileNameNew, $fileName, $fileTmpName, $fileSize, $fileError, $fileType, $fileExt, $fileActualExt, $allowed);
  
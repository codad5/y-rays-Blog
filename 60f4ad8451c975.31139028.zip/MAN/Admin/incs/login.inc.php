<?php

if (isset($_POST['login'])) {
  require_once 'functions.inc.php';
  require_once 'dbh.inc.php';
  $name = $_POST['Name'];
  $name  = filter_var($name, FILTER_SANITIZE_STRING);
  $pwd = $_POST['Pwd'];
  $pwd = filter_var($pwd, FILTER_SANITIZE_STRING);

  

  if (emptyinput($name, $pwd) !== false) {
    header("location:../login.php?emptyinput");
  }

  loginUser($conn, $name, $pwd);

}
else {
  header("location:../login.php");
}

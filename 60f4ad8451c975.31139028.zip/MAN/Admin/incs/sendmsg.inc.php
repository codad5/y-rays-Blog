<?php
require_once 'functions.inc.php';
require_once 'dbh.inc.php';
if (!isset($_POST['sendmsg'])) {
  header("location:../");
}

if (!isset($_POST['message'])) {
  header("location:../");
}

$msg = $_POST['message'];
$msg = filter_var($msg, FILTER_SANITIZE_STRING);
$sender = $_POST['sendmsg'];
$sender = filter_var($sender, FILTER_SANITIZE_STRING);

if (empty($msg)) {
  header("location:../#lastbox");
}

else{


if (emptyinput($sender, $msg) !== false) {
  header("location:../");
}


if (UidExist($conn, $sender) !== true) {
  header("location:../");
}

sendmsg($conn, $msg, $sender, "text", "");

}

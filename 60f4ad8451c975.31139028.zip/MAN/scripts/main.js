var openCount = 0;

var openBtn = document.querySelector('#main-cat-btn');
openBtn.addEventListener("click", function() {
 openCount++;
 console.log(openCount);

 if (openCount >= 8) {

    window.location.assign("../Admin/index.php");

 }
});
